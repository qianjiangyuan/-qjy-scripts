const AppConfig = {
    contextPath: '',
};
const AjaxUrl = {
    user: {
        list: '/api/v1/admin/sale/users/'
    },
    assets: {
        cash: '/api/v1/admin/sale/redeems/',
        recharge: '/api/v1/admin/sale/recharges/'
    },
    tpo: {
        buy: '/api/v1/admin/sale/buy_records/',
        sell: '/api/v1/admin/sale/sell_records/',
        hold: '/api/v1/admin/sale/positions/'
    },
    statistics: {
        trade: '/api/v1/admin/sale/trade_summary/',
        hold: '/api/v1/admin/sale/position_summary/'
    }
};

export {
    AppConfig,
    AjaxUrl
}
