import { Component } from '@angular/core';
import { SharkAjax, SharkValidRuleService, Common, UserService, Ajax } from "./shared/shared.module";

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
    uid: string;

    constructor(
        private ruleService: SharkValidRuleService,
        private common: Common,
        private sharkAjax: SharkAjax,
        private ajax: Ajax,
        private userService: UserService
    ) {

        //定义校验规则
        ruleService.setRule('strongRequired', (value, dataModel) => {
            if (this.common.isEmpty(value) || (typeof (value) == 'string' && this.common.isEmpty(value.trim()))) {
                return { required: true };
            } else {
                return { required: false };
            }
        });

        //定义校验规则
        ruleService.setErrorInfo('stockRequired', '股票代码无效');
        ruleService.setRule('stockRequired', (value, dataModel) => {
            if (this.common.isEmpty(value) || (typeof (value) == 'string' && this.common.isEmpty(value.trim()))) {
                return { stockRequired: true };
            } else {
                if (value.length == 6) {
                    return { stockRequired: !Boolean(Number(value)) };
                } else {
                    return { stockRequired: true };
                }
            }
        });

        ruleService.setErrorInfo('realNumber', '数字无效');
        ruleService.setRule('realNumber', (value, dataModel) => {
            return { realNumber: isNaN(Number(value)) };
        });

        //设置xsrf
        this.ajax.setHttpXsrf({
            cookieName: 'csrftoken',
            headerName: 'X-CSRFToken'
        });

        this.sharkAjax.setHttpXsrf({
            cookieName: 'csrftoken',
            headerName: 'X-CSRFToken'
        });

        //
        this.ajax.setFilterCode((res) => {
            return res.code === 0;
        });

        this.sharkAjax.setFilterCode((res) => {
            return res.code === 0;
        });

        //set
        this.userService.setUserToken(window.localStorage.getItem('account_token'));

        //get
        let uid = window.localStorage.getItem('uid');
        this.uid = uid ? uid : '';
    }

    logout() {
        window.localStorage.setItem('account_token', '');
        window.location.href = '/admin/sales/login';
    }

}