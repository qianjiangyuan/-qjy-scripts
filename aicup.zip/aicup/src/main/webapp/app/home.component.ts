import { Component } from '@angular/core';

@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent {
    fileList: any[] = [];
    url: string = 'http://aicup.qjycloud.com/upload?type=1&round=1';

    constructor(
    ) {

    }

    onSelected = (e) => {
        console.log(e)

    }

    onCompleted = (e) => {
        console.log(e)
    }

    submit() {
        console.log(this.fileList)
    }
};
