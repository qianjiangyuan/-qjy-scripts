import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'percent' })
export class PercentPipe implements PipeTransform {
    transform(value) {
        if (typeof value !== 'number') {
            return '--';
        }
        return (value * 100).toFixed(1) + '%';
    }
};

@Pipe({ name: 'percent100' })
export class Percent100Pipe implements PipeTransform {
    transform(value1) {
        let value = Number(value1);
        if (typeof value !== 'number') {
            return '--';
        }
        return Math.round(value * 100)+ '%';
    }
};