import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'tradeState' })
export class TradeStateePipe implements PipeTransform {
    map: any = {
        2: '交易成功',
        3: '交易失败',
        4: '交易超时',
        5: '交易撤销'
    };

    transform(index: any) {
        return this.map[index] || '--';
    }
}

@Pipe({ name: 'rechargeState' })
export class RechargeStatePipe implements PipeTransform {
    map: any = {
        1: '未充值',
        2: '已超时',
        3: '充值成功',
        4: '充值异常'
    };

    transform(index: any) {
        return this.map[index] || '--';
    }
}

@Pipe({ name: 'cashState' })
export class CashStatePipe implements PipeTransform {
    map: any = {
        1: '提现中',
        2: '提现成功',
        3: '提现失败'
    };

    transform(index: any) {
        return this.map[index] || '--';
    }
}

@Pipe({ name: 'bool', pure: false })
export class BoolPipe implements PipeTransform {
    constructor(
    ) { }

    transform(value: any) {
        return value == undefined ? '-' : (Boolean(value) ? '是' : '否');
    }
}
