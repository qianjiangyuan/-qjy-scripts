/***********common module***************/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharkModule } from './shark/shark.module';
/***********common things***************/
import { TradeStateePipe, RechargeStatePipe, CashStatePipe, BoolPipe } from './pipes/status.pipe';
import { PercentPipe, Percent100Pipe } from './pipes/percent.pipe';
import { AutosizeDirective } from './directives/autosize.directive';
/***********common service***************/
import { UserService } from './services/user.service';
import { Ajax } from './services/ajax.service';

let modules: Array<any> = [CommonModule, FormsModule, SharkModule];
let services: Array<any> = [UserService, Ajax];
let directives: Array<any> = [AutosizeDirective];
let pipelines: Array<any> = [PercentPipe, Percent100Pipe, TradeStateePipe, RechargeStatePipe, CashStatePipe, BoolPipe];

@NgModule({
    imports: [],
    declarations: [...directives, ...pipelines],
    providers: [...services],
    exports: [...modules, ...directives, ...pipelines]
})
export class SharedModule { }
export * from './shark/shark.module';
export { UserService, Ajax }