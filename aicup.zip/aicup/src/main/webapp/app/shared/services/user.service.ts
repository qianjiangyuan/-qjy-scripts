import { Injectable } from '@angular/core';
import { AjaxUrl } from '../../config';
import { SharkAjax } from '../shark/util/ajax.service';

@Injectable()
export class UserService {
    static user: any;
    static token: any;

    static isLoaded: Promise<any>;

    constructor(
        private ajax: SharkAjax
    ) { }

    setUserToken(token) {
        if (token) {
            UserService.token = token;
        }
    }

    getUserToken() {
        return new Promise(async (resolve, reject) => {
            if (UserService.token) {
                resolve(UserService.token);
            } else {
                window.location.href='/admin/sales/login'
                reject();
            }
        })
    }

    getUserInfo() {
        return UserService.user;
    }

    setUserInfo(user) {
        UserService.user = user;
    }



    public updateInfo() {

    }
}