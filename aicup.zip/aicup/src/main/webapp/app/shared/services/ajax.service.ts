import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpEventType, HttpHeaders, HttpParams, HttpClientXsrfModule } from '@angular/common/http';
import { Common,Cookie,SharkUI } from '../shark/shark.module';
import { UserService } from './user.service';

@Injectable()
export class Ajax {
    private filter: any = {
        contextPath: '',
        filterCode: (result, type) => {
            if (type === 'head') {
                return true;
            } else {
                return result.code === 200;
            }
        },
        filterData: (result, type) => {
            return result;
        },
        filterHttpError: (err) => {
            return {
                code: err.status,
                errorType: 'http',
                message: err.message,
                originError: err
            };
        }
    };
    // xsrf的配置项
    private xsrfConfig;
    constructor(
        private http: HttpClient,
        private common: Common,
        private cookie: Cookie,
        private userService: UserService
    ) {
        this.xsrfConfig = {
            cookieName: 'YX_CSRF_TOKEN',
            headerName: 'Yx-Csrf-Token'
        };
        SharkUI.setConfig('csrf', {
            cookieName: 'YX_CSRF_TOKEN',
            headerName: 'Yx-Csrf-Token'
        });
    }
    setContextPath(contextPath) {
        this.filter.contextPath = contextPath;
    }
    setFilterCode(fn) {
        this.filter.filterCode = fn;
    }
    setFilterData(fn) {
        this.filter.filterData = fn;
    }
    setFilterError(fn) {
        this.filter.filterHttpError = fn;
    }
    setHttpXsrf(config: {
        cookieName?: string,
        headerName?: string
    }) {
        Object.assign(this.xsrfConfig, config);
        SharkUI.setConfig('csrf', config);
    }
    getHttpXsrf() {
        return this.xsrfConfig;
    }

    //ajax缓存
    private ajaxCache: Map<string, any> = new Map<string, any>();

    //ajax缓存时间，默认10分钟
    private ajaxCacheTime: number = 1000 * 60 * 10;

    private isCacheExpired(cacheObj, time) {
        return Date.now() - cacheObj.timestamp <= time ? false : true;
    }

    private getCache(url, params, cache) {
        if (cache) {
            let cacheArr = this.ajaxCache.get(url);
            if (cacheArr) {
                let time = typeof cache === 'number' ? cache : this.ajaxCacheTime;
                for (let i = 0; i < cacheArr.length; i++) {
                    let cacheObj = cacheArr[i];
                    if (this.isCacheExpired(cacheObj, time)) {
                        cacheArr.splice(i, 1);
                        --i;
                        continue;
                    }
                    if (this.common.isEqual(params, cacheObj.params)) {
                        return cacheObj;
                    }
                }
                return null;
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    }

    private removeCache(url, params) {
        let cacheArr = this.ajaxCache.get(url);
        if (cacheArr) {
            for (let i = 0; i < cacheArr.length; i++) {
                let cacheObj = cacheArr[i];
                if (this.common.isEqual(params, cacheObj.params)) {
                    cacheArr.splice(i, 1);
                    --i;
                }
            }
        }
    }

    //post、path、put请求的参数都可以放到请求的body中，支持application/x-www-form-urlencoded或者application/json两种方式

    /**
     * post
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public post(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'post', cache || false);
    }

    /**
     * post request payload
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public postByJson(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'postjson', cache || false);
    }

    /**
     * patch
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public patch(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'patch', cache || false);
    }

    /**
     * patch equest payload
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public patchByJson(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'patchjson', cache || false);
    }

    /**
     * put
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public put(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'put', cache || false);
    }

    /**
     * put request payload
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public putByJson(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'putjson', cache || false);
    }

    /**
     * upload file 支持IE10以上浏览器
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public upload(url: string, params?: Object, cb?: Function): Promise<any> {
        if (!params) {
            params = {};
        }
        if (arguments.length === 2 && typeof params === 'function') {
            cb = params;
            params = {};
        }
        return this.doRequest(url, params, 'file', false, cb);
    }

    //get、delete、options、head请求的参数都需要添加到url后面

    /**
     * get
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public get(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'get', cache || false);
    }

    /**
     * delete
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public delete(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'delete', cache || false);
    }

    /**
     * options
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public options(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'options', cache || false);
    }

    /**
     * head (head请求没有body返回)
     * @param [url] 请求路径
     * @param [params] 请求参数，没有可以传null
     * @param [url] 缓存时间，不传或者传false表示不缓存，传数字表示缓存的时间（毫秒值）
     */
    public head(url: string, params?: Object, cache?: boolean | number): Promise<any> {
        return this.doRequest(url, params, 'head', cache || false);
    }

    /**
     * jsonp
     * @param [url] 请求路径
     * @param [callbackName] callback的名字
     * @param [params] 参数
     */
    public jsonp(url: string, callbackName?, params?: Object): Promise<any> {
        if (params) {
            for (let p in params) {
                if (params.hasOwnProperty(p)) {
                    if (url.indexOf('?') > -1) {
                        url = url + '&' + p + '=' + params[p];
                    } else {
                        url = url + '?' + p + '=' + params[p];
                    }
                }
            }
        }
        if (url.indexOf('?') > -1) {
            url = url + '&' + '_rnd' + '=' + Date.now();
        } else {
            url = url + '?' + '_rnd' + '=' + Date.now();
        }
        return this.doRequest(url, { callbackName: callbackName }, 'jsonp', false);
    }

    // 构造HttpParams数据类型
    private setHttpParams(params) {
        let httpParams = new HttpParams();
        if (typeof params === 'object' && params !== null) {
            httpParams = Object.keys(params).reduce(function (httpParams, param) {
                return httpParams.set(param, params[param]);
            }, httpParams);
        }
        return httpParams;
    }

    // 构造FormData数据类型
    private setFormData(params) {
        let data = new FormData();
        for (let p in (params as any)) {
            if (params.hasOwnProperty(p)) {
                data.append(p, params[p]);
            }
        }
        return data;
    }

    // 设置防xsrf攻击的header
    private setXsrfHeader(headers) {
        if (this.xsrfConfig.cookieName && this.xsrfConfig.headerName) {
            let xsrfCookie = this.cookie.getCookie(this.xsrfConfig.cookieName);
            if (xsrfCookie) {
                headers = headers.set(this.xsrfConfig.headerName, xsrfCookie);
            }
        }
        return headers;
    }

    // 设置HttpHeaders
    public setHttpHeaders(params) {
        let headers = new HttpHeaders();
        headers = Object.keys(params).reduce(function (headers, name) {
            return headers.set(name, params[name]);
        }, headers);
        // 设置防xsrf攻击的header
        headers = this.setXsrfHeader(headers);
        return headers;
    }

    private doRequest(url: string, params: any, type: string, cache: boolean | number, cb?: Function) {
        url = this.filter.contextPath + url;
        let cacheObj = this.getCache(url, params, cache);
        if (!this.common.isEmpty(cacheObj)) {
            return cacheObj.promise;
        } else {
            let sub: any;
            let p: any = new Promise(async (resolve, reject) => {
                let o: any;
                if (type === 'post') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    });
                    o = this.http.post(url, httpParams, {
                        headers: headers
                    });
                }
                else if (type === 'postjson') {
                    let headers = this.setHttpHeaders({
                        'Content-Type': 'application/json; charset=UTF-8',
                    });
                    o = this.http.post(url, params, {
                        headers: headers
                    });
                }
                else if (type === 'patch') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
                    o = this.http.patch(url, httpParams, {
                        headers: headers
                    });
                }
                else if (type === 'patchjson') {
                    let headers = this.setHttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8' });
                    o = this.http.patch(url, params, {
                        headers: headers
                    });
                }
                else if (type === 'put') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
                    o = this.http.put(url, httpParams, {
                        headers: headers
                    });
                }
                else if (type === 'putjson') {
                    let headers = this.setHttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8' });
                    o = this.http.put(url, params, {
                        headers: headers
                    });
                }
                else if (type === 'file') {
                    let data = this.setFormData(params);
                    let headers = this.setHttpHeaders({});
                    const req = new HttpRequest('POST', url, data, {
                        reportProgress: true,
                        headers: headers
                    });
                    o = this.http.request(req);
                }
                else if (type === 'get') {
                    if (!params) {
                        params = {};
                    }
                    if (SharkUI.isIE9()) {
                        params._rnd = Date.now();//IE9方式GET缓存
                    }
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    });
                    o = this.http.get(url, {
                        headers: headers,
                        params: httpParams
                    });
                }
                else if (type === 'delete') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({});
                    o = this.http.delete(url, {
                        headers: headers,
                        params: httpParams
                    });
                }
                else if (type === 'options') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({});
                    o = this.http.options(url, {
                        headers: headers,
                        params: httpParams
                    });
                }
                else if (type === 'head') {
                    let httpParams = this.setHttpParams(params);
                    let headers = this.setHttpHeaders({});
                    o = this.http.head(url, {
                        headers: headers,
                        params: httpParams
                    });
                }
                else if (type === 'jsonp') {
                    o = this.http.jsonp(url, params.callbackName);
                }
                sub = o.subscribe((result) => {
                    if (type === 'file') {
                        if (result instanceof HttpResponse) {
                            result = result.body;
                        } else {
                            // 上传进度
                            if (cb && (result.type === HttpEventType.UploadProgress)) {
                                cb(result);
                            }
                            return;
                        }
                    }
                    if (this.filter.filterCode(result, type)) {
                        let data = this.filter.filterData(result, type);
                        resolve(data);
                    } else {
                        if (cache) {
                            this.removeCache(url, params);
                        }
                        reject(result);
                    }
                }, (error: any) => {
                    if (cache) {
                        this.removeCache(url, params);
                    }
                    let err = this.filter.filterHttpError(error);
                    reject(err);
                });
            });
            p.sub = sub;
            if (cache) {
                let cacheArr = this.ajaxCache.get(url) || [];
                let cacheObj = {
                    timestamp: Date.now(),
                    params: this.common.copy(params),
                    promise: p
                };
                cacheArr.push(cacheObj);
                this.ajaxCache.set(url, cacheArr);
            }
            return p;
        }
    }
}
