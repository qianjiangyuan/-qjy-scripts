import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { AppConfig } from './config';
import { SharkAjax, Ajax } from './shared/shared.module';

console.log(ENV)

if (ENV === 'prod') {
    enableProdMode()
}

// 定义常量 路由
const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full'
    }
    , {
        path: 'home',
        component: HomeComponent
    }
]

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        SharedModule,
        RouterModule.forRoot(appRoutes, { useHash: true }),
    ],
    declarations: [AppComponent, HomeComponent],
    bootstrap: [AppComponent]
})
export class AppModule {
    constructor(
        private sharkAjax: SharkAjax,
        private ajax: Ajax
    ) {
        this.ajax.setContextPath(AppConfig.contextPath);
        this.sharkAjax.setContextPath(AppConfig.contextPath);
    }
}
