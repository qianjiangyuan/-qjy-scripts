declare module '*app.module.ngfactory';
declare var ENV: string;
declare var HOT: boolean;
declare var $: any;
