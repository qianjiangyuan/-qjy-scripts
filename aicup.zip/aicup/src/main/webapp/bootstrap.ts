// bootstrap
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';

// hmr
if (ENV !== 'prod' && HOT) {
    if ((module as any).hot) {
        (module as any).hot.accept();
    }
}

platformBrowserDynamic().bootstrapModule(AppModule);
