const path = require('path');

/**
 * 本文件为template 私有化的配置中心，
 * 需要用户自定义需改的配置为 const 定义的常量，使用文档请参 README.md
 */

// git 仓库中的groupName，需配置
const groupName = '';
// git 仓库中的productName，需配置
const productName = '';
// 应用的contextPath，需配置，没有填空字符串
const contextPath = '';
//【1.3.0新增】部署服务时需要的配置文件及所在服务器路径
const serverConfigPath = '/home/wpd/shark-deploy/config/deploy.js';
//【1.3.0新增】开发时后端提供的链接
//const remoteUrl = 'https://test.tradewinner.cn';
const remoteUrl = 'https://unicornhunter.cn';

module.exports = {
    __dirname: __dirname,
    // 此处为端口号为 basePort， shark 会帮你自动选择可用的端口号
    port: 9300,
    // 项目名
    product: productName,
    //【1.3.0新增】 组名
    groupName: groupName,
    //【1.3.0新增】部署配置文件及路径
    serverConfigPath: serverConfigPath,
    //【1.3.1新增】是否开启热更新，不设置（向前兼容）或者设置为 false 表示开启热更新，默认开启 false
    closeHotReload: false,
    //【1.3.1新增】是否兼容 IE9 及以上，默认 false，设置为 true 会在 polyfillChunk 中注入 'classlist-polyfill','babel-polyfill','raf' 兼容包
    shimIE9: false,
    //【1.3.0新增】项目中全局样式目录， 默认包含 'src/main/webapp/styles/scss/index.scss'
    styleChunk: [],
    //【1.3.0新增】项目中使用的 polyfill, 默认包含 'core-js/es6/reflect', 'core-js/es7/reflect', 'zone.js/dist/zone'
    polyfillChunk: [],
    //【1.3.0新增】此处定义需要打包到 dll 中的第三方包，默认包含 '@angular/animations', '@angular/common', '@angular/core', '@angular/forms', '@angular/http', '@angular/platform-browser', '@angular/platform-browser-dynamic', '@angular/router'
    customModules: [],
    // 项目前缀
    contextPath: contextPath,
    // 远端联调地址，一般是测试机的对外ip+服务端的端口。
    remote: {
        url: remoteUrl
    },
    // 打包生成 index.html时插入的 CDN 前缀，此处需要与 shark-deploy 部署时提供的静态文件前缀保持一致
    mimgURLPrefix: {
        dev: `http://cdn.zaiyan.com.cn/`,
    }
};