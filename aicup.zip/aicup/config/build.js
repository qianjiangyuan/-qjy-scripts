const SharkWebpack = require('./shark-angularX-webpack');
const sw = new SharkWebpack(require('../shark-deploy-conf'));
const fse = require('fs-extra');
const path = require('path');
const argv = require('yargs').argv;
const contextPath = path.join(__dirname, '..');

const deployOption = {
    target: argv.target,
    branch: argv.branch,
    callback: () => {

        fse.copySync(`${contextPath}/src/main/webapp/login.html`, `${contextPath}/build/app/login.html`);
    }
};
sw.runBuild(deployOption);// 自定义插件方式请参考 shark-angularX-webpack