const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');
const merge = require('webpack-merge');
const mergeDirConfig = require('./utils/mergeconfig');
const CheckDllExist = require('./utils/check-dll-exist');
const DefinePlugin = require('webpack/lib/DefinePlugin');

class Shark {
    /**
     * 配置文件所用的 webpack
     *
     * @readonly
     * @memberof Shark
     */
    get webpack() {
        return require('webpack');
    }

    /**
     * webpack-dev-middleware
     *
     * @readonly
     * @memberof Shark
     */
    get webpackDevMiddleware() {
        return require('webpack-dev-middleware');
    }

    /**
     * webpack-hot-middleware
     *
     * @readonly
     * @memberof Shark
     */
    get webpackHotMiddleware() {
        return require('webpack-hot-middleware');
    }

    constructor(config) {
        this.config = mergeDirConfig(config);
    }

    /**
     * 获取dev包所需要的配置文件，此方法只用于兼容老版本 手动 npm run dll 需求
     * 新版本中使用自动化 dll 方式
     *
     * @param {any} strategy 同webpack-merge smartStrategy 接口使用的合并策略参数(option)
     * @param {any} custom 自定义的配置(option)
     * @returns
     * @memberof Shark
     */
    getDevConfig(strategy, custom) {
       return this.getConfig('dev', strategy, custom);
    }

    /**
     * 获取dll包所需要的配置文件
     *
     * @param {any} strategy 同webpack-merge smartStrategy 接口使用的合并策略参数(option)
     * @param {any} custom 自定义的配置(option)
     * @returns
     * @memberof Shark
     */
    getDllConfig(strategy, custom) {
        return this.getConfig('dll', strategy, custom);
    }

    /**
     * 获取build包所需要的配置文件
     *
     * @param {any} strategy 同webpack-merge smartStrategy 接口使用的合并策略参数(option)
     * @param {any} custom 自定义的配置(option)
     * @returns
     * @memberof Shark
     */
    getBuildConfig(strategy, custom) {
        return this.getConfig('build', strategy, custom);
    }

    /**
     * 通过传入 config 类型来使用获取 config 配置
     *
     * @param {string} configType config的类型 'build' | 'dev' | 'dll'
     * @param {any} strategy 同webpack-merge smartStrategy 接口使用的合并策略参数(option)
     * @param {any} custom 自定义的配置(option)
     * @returns
     * @memberof Shark
     */
    getConfig(configType, strategy, custom) {
        this.checkConfigs(strategy, custom);
        if (configType !== 'build' && configType !== 'dev' && configType !== 'dll') {
            console.log(chalk.red('[ERR] config type need to be: build | dev | dll'))
        } else {
            const thisConfig = require(`./config/webpack.${configType}.config`)(this.config);
            let resultConfig = {};
            if (strategy && strategy.plugins && strategy.plugins === 'replace-spec') {
                if(Array.isArray(custom.plugins)){
                    let customPluginNames = custom.plugins.map(plugin => plugin.constructor && plugin.constructor.name);
                    let customReplace = merge({
                        customizeArray: merge.unique(
                            'plugins', customPluginNames,
                            plugin => plugin.constructor && plugin.constructor.name
                        )
                    })({
                        plugins: custom.plugins
                    }, {
                        plugins: thisConfig.plugins
                    });
                    resultConfig = merge.smartStrategy({
                        plugins: 'replace'
                    })(thisConfig, customReplace);
                    if(Object.keys(strategy).length > 1){
                        resultConfig = merge.smartStrategy(strategy)(resultConfig, custom);
                    }
                }else{
                    console.error('custom.plugins is not set');
                }
            }else{
                resultConfig = merge.smartStrategy(strategy)(thisConfig, custom);
            }
            return resultConfig;
        }
    }

    /**
     * 获取 index.html 的实际值
     * todo: 此处使用了第一个 htmlWebpackPlugin 设置的值，实际上，多个值时应该由 shark-deploy-conf 来配置
     *
     * @memberof Shark
     */
    getIndexHtml(config) {
        return config.plugins.filter(plugin => plugin.constructor && plugin.constructor.name === 'HtmlWebpackPlugin')[0].options.filename;
    }

    checkConfigs(strategy, custom) {
        if (strategy && strategy.entry) {
            console.log(chalk.yellow.bold(`[WARN] you have change entry`));
            // console.log(chalk.yellow.bold(`[WARN] shark-webpack has strict entry settings, make sure you know it. Put all the settings into shark-deploy-conf.js is all we want.
            //  More references: `))
            // console.log(chalk.blue.underline('https://git.mail.netease.com/shark/shark-angularx-template'));
        }
    }

    /**
     * 检查dll 文件的有效性，需要打包的文件变动或者打包文件版本变动都会引发自动重新构建 dll
     *
     * @returns Promise
     * @memberof Shark
     */
    checkDll() {
        let isExist = new CheckDllExist().check(this.config);
        return new Promise((resolve, reject) => {
            if (!isExist) {
                console.log(chalk.yellow('[INFO] Dll config is change, auto running dll ...'));
                const dllConfig = require('./config/webpack.dll.config')(this.config);
                this.webpack(dllConfig, function (err, states) {
                    if (err) {
                        reject(err);
                        process.exit(0);
                    }
                    process.stdout.write(states.toString({
                        colors: true,
                        modules: false,
                        children: false,
                        chunks: false,
                        chunkModules: false
                    }) + '\n');
                    resolve(chalk.green('[INFO] Dll done'));
                });
            } else {
                resolve(chalk.gray('[INFO] Dll is ready'));
            }
        })
    }

    /**
     * 文件拷贝，替代 gulp
     *
     * @param {any} src
     * @param {any} dist
     * @param {any} regexp
     * @param {boolean} [dir=false]
     * @memberof Shark
     */
    copyFiles(src, dist, regexp, dir = false) {
        fs.readdirSync(src).forEach(file => {
            if (regexp.test(file)) {
                fs.ensureDirSync(dist);
                fs.copySync(path.join(src, file), path.join(dist, file))
            }
        });
        src = src.slice(process.cwd().length);
        dist = dist.slice(process.cwd().length);
        console.log(chalk.gray(`[COPY] ${regexp} FROM ${src} TO ${dist}`));
    }

    /**
     * 执行 build 操作，传入 options 包含
     *
     * @param {any} options.target 构建的目标， 不传 | test | online 不传为本地编译，主要影响index.html中资源地址拼接
     * @param {any} options.branch 构建的代码分支  dev | master | ... 暂未使用
     * @param {any} options.buildConfig 用户传入的配置  customConfig = sharkWebpack.getBuildConfig() 所得
     * @param {function} options.callback webpack 打包完成后的回调，可以进行打包结果的拷贝
     * @memberof Shark
     */
    runBuild(options) {
        let dependencies = [];
        try {
            let packageJson = require(path.join(this.config.__dirname, 'package.json'));
            for (let dep in packageJson.dependencies) {
                if (dep.indexOf('@angular') < 0 && dep.indexOf('@type') < 0) {
                    dependencies.push(dep);
                }
            }
        } catch (e) {
            throw e
        }
        let target = options.target;
        let branch = options.branch;
        let ng6packages = options.ng6packages || dependencies;
        let callback = options.callback || (() => {
        });
        let buildConfig = options.buildConfig ? options.buildConfig : this.getBuildConfig();
        if (target) {
            buildConfig.plugins.push(new DefinePlugin({
                'ENV': '"prod"',
                'ENV_PROD': target === 'test' ? '"prod:test"' : '"prod"'
            }));
            buildConfig.output.publicPath = this.config['mimgURLPrefix'][target];
        }

        ng6packages.forEach(p => {
            try {
                let packageJsonPath = path.join(this.config.nodeModules, p, 'package.json');
                let metadataJsonName = require(packageJsonPath).metadata;
                if (metadataJsonName) {
                    let metadataJsonPath = path.join(this.config.nodeModules, p, metadataJsonName);
                    let metadata = require(metadataJsonPath);
                    fs.writeJsonSync(metadataJsonPath, Object.assign(metadata, {
                        version: 3
                    }));
                }
            } catch (e) {
                throw e
            }
        });
        let config = this.config;
        let copyFiles = this.copyFiles;
        this.webpack(buildConfig, function (err, states) {
            if (err || states.hasErrors()) {
                throw err || states.compilation.errors;
            }
            process.stdout.write(states.toString({
                bail: true,
                colors: true,
                modules: true,
                children: false,
                chunks: true,
                chunkModules: false,
                timings: true
            }) + '\n');

            copyFiles(config.srcPath, config.buildWebapp, /\.ico$/);
            copyFiles(config.buildClient, config.buildWebapp, /\.html$/);
            copyFiles(config.buildClient, config.buildStatics, /(js|css|img)\/*/);
            //执行用户提供的回调代码
            callback();
        });
    }
}

module.exports = Shark;