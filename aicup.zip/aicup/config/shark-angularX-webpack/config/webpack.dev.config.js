const path = require('path');

const NamedLazyChunksWebpackPlugin = require('../utils/named-lazy-chunks-webpack-plugin');
const DisableEndlessCompilePlugin = require('../utils/disable-endless-compile-plugin');

const DefinePlugin = require('webpack/lib/DefinePlugin');
const {HotModuleReplacementPlugin, DllReferencePlugin, SourceMapDevToolPlugin} = require('webpack');
const {CommonsChunkPlugin} = require('webpack').optimize;

const ProgressBarWebpackPlugin = require('progress-bar-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin');
const {CheckerPlugin} = require('awesome-typescript-loader');

module.exports = function (config) {
    return {
        entry: {
            bootstrap: [path.join(config.srcPath, 'bootstrap.ts'), 'webpack-hot-middleware/client?&reload=true'],
            style: config.styleChunk.concat(['webpack-hot-middleware/client?&reload=true']),
            polyfill: config.polyfillChunk
        },
        output: {
            path: config.buildClient,
            filename: 'js/[name].js',
            chunkFilename: 'js/chunk-[name].js',
            publicPath: config.contextPath + '/'
        },
        module: {
            rules: [{
                test: /\.js$/,
                include: [
                    path.join(config.__dirname)
                ],
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['env']
                    }
                }
            },
                {
                    test: /\.ts$/,
                    use: [{
                        loader: 'awesome-typescript-loader',
                        options: {
                            silent: true,
                            useCache: true,
                            forceIsolatedModules: true,
                            cacheDirectory: path.join(config.__dirname, 'node_modules/.cache/atl/'),
                            reportFiles: config.srcPath + '/**/*.ts',
                            configFileName: config.tsConfigFile
                        }
                    }, {
                        loader: 'angular2-template-loader'
                    }, {
                        loader: 'angular-router-loader'
                    }]
                },
                {
                    test: /\.html$/,
                    use: {
                        loader: 'html-loader'
                    }
                },
                {
                    test: /\.(jpg|png|webp|gif)$/,
                    use: {
                        loader: 'url-loader',
                        options: {
                            name: 'img/[name]-[hash:12].[ext]',
                            limit: 100
                        }
                    }
                },
                {
                    test: /\.(otf|ttf|woff|woff2|ani|eot|svg|cur)$/,
                    // limit参数，数据类型为整型，表示目标文件的体积大于多少字节就换用file-loader来处理了
                    // 不填则永远不会交给file-loader处理, 单位 byte
                    loader: 'url-loader?name=font/[name].[hash:12].[ext]'
                },
                {
                    test: /\.scss$/,
                    include: path.join(config.srcPath, 'styles'),
                    use: ['style-loader', 'css-loader', 'sass-loader']
                },
                {
                    test: /\.scss$/,
                    include: [
                        path.join(config.srcPath, 'app'),
                        ...config.scssPath
                    ],
                    use: [
                        'to-string-loader',
                        'css-loader',
                        'sass-loader'
                    ]
                },
                {
                    test: /\.ejs$/,
                    include: [
                        path.join(config.srcPath)
                    ],
                    use: {
                        loader: 'ejs-loader'
                    }
                }
            ]
        },
        resolve: {
            extensions: ['.ts', '.js']
        },
        plugins: [
            // 使用 happypack 加速编译和构建
            new CheckerPlugin(),
            // 日志输出格式化
            new ProgressBarWebpackPlugin(),
            new HotModuleReplacementPlugin(),
            // 给 chunk 命名，便于查看打包
            new NamedLazyChunksWebpackPlugin(),
            new DefinePlugin({
                'ENV': '"dev"',
                'HOT': !config.closeHotReload,
                'ENV_PROD': '"dev"'
            }),
            new HtmlWebpackPlugin({
                filename: 'index.html',
                favicon: path.join(config.srcPath, 'favicon.ico'),
                template: path.join(config.srcPath, 'index.ejs')
            }),
            new CommonsChunkPlugin({
                names: ['bootstrap', 'style', 'polyfill']
            }),
            new AddAssetHtmlPlugin([
                {filepath: path.join(config.dllPath, 'angular.dll.js')}
            ]),
            new DllReferencePlugin({
                context: config.__dirname,
                manifest: require(path.join(config.dllPath, 'angular-manifest.json'))
            }),
            new SourceMapDevToolPlugin({
                filename: '[file].map[query]',
                moduleFilenameTemplate: '[resource-path]',
                fallbackModuleFilenameTemplate: '[resource-path]?[hash]',
                sourceRoot: 'webpack:///'
            }),
            new DisableEndlessCompilePlugin()
        ]
    };
};