const path = require('path');
const fs = require('fs-extra');
const ngtools = require('@ngtools/webpack');

const NamedLazyChunksWebpackPlugin = require('../utils/named-lazy-chunks-webpack-plugin');
const SuppressExtractedTextChunksWebpackPlugin = require('../utils/suppress-entry-chunks-webpack-plugin');
const WebpackOutputContentHashPlugin = require('../utils/webpack-output-content-hash-plugin');

const {HashedModuleIdsPlugin} = require('webpack');
const DefinePlugin = require('webpack/lib/DefinePlugin');
const {OccurrenceOrderPlugin, CommonsChunkPlugin, ModuleConcatenationPlugin} = require('webpack').optimize;

const HtmlWebpackPlugin = require('html-webpack-plugin');
const ProgressBarWebpackPlugin = require('progress-bar-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

const entryPoints = ['polyfill', 'entry', 'angular', 'thirdParty', 'bootstrap'];

module.exports = function (config) {

    const nodeModules = path.join(config.__dirname, 'node_modules');
    const realNodeModules = fs.realpathSync(nodeModules);
    const genDirNodeModules = path.join(config.__dirname, '$$_gendir', 'node_modules');

    return {
        entry: {
            bootstrap: [path.join(config.srcPath, 'bootstrap.ts')].concat(config.styleChunk),
            polyfill: config.polyfillChunk
        },
        output: {
            path: config.buildClient,
            filename: '[name].[chunkhash:12].js',
            chunkFilename: 'chunk-[id].[chunkhash:12].js',
            publicPath: config.contextPath + '/'
        },
        module: {
            rules: [{
                test: /\.js$/,
                include: [
                    path.join(config.__dirname)
                ],
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['env']
                    }
                }
            },
                {
                    test: /\.ts$/,
                    use: '@ngtools/webpack'
                },
                {
                    test: /\.html$/,
                    use: 'html-loader'
                },
                {
                    test: /\.(jpg|png|webp|gif)$/,
                    use: {
                        loader: 'url-loader',
                        options: {
                            name: 'img/[name]-[hash:12].[ext]',
                            limit: 100
                        }
                    }
                },
                {
                    test: /\.(otf|ttf|woff|woff2|ani|eot|svg|cur)$/,
                    // limit参数，数据类型为整型，表示目标文件的体积大于多少字节就换用file-loader来处理了
                    // 不填则永远不会交给file-loader处理, 单位 byte
                    loader: 'url-loader?name=font/[name].[hash:12].[ext]'
                },
                {
                    test: /\.scss$/,
                    include: [
                        path.join(config.srcPath, 'styles')
                    ],
                    use: ExtractTextPlugin.extract({
                        fallback: 'style-loader',
                        use: ['css-loader?minimize', 'sass-loader']
                    })
                },
                {
                    test: /\.scss$/,
                    include: [
                        path.join(config.srcPath, 'app'),
                        ...config.scssPath
                    ],
                    use: [
                        'to-string-loader',
                        'css-loader',
                        'sass-loader'
                    ]
                },
                {
                    test: /\.ejs$/,
                    include: [
                        path.join(config.srcPath)
                    ],
                    use: 'ejs-loader'
                }
            ]
        },
        resolve: {
            extensions: ['.ts', '.js'],
            modules: [path.resolve(config.__dirname, 'node_modules')]
        },
        profile: true,
        plugins: [
            new HashedModuleIdsPlugin(),
            new NamedLazyChunksWebpackPlugin(),
            new OccurrenceOrderPlugin(),
            new ModuleConcatenationPlugin(),
            new ProgressBarWebpackPlugin(),
            new CleanWebpackPlugin([config.build + '/**/*'], {
                root: config.__dirname,
                verbose: false
            }),
            new UglifyJsPlugin({
                exclude: /node_modules/,
                cache: path.join(config.__dirname, 'node_modules/.cache/pup/'),
                parallel: true,
                uglifyOptions: {
                    output: {
                        comments: false
                    },
                    compress: {
                        warnings: false
                    }
                }
            }),
            new DefinePlugin({
                'ENV': '"prod"'
            }),
            new ExtractTextPlugin('[name].[contenthash:12].css'),
            new SuppressExtractedTextChunksWebpackPlugin(),
            new HtmlWebpackPlugin({
                filename: 'index.html',
                template: path.join(config.srcPath, 'index.ejs'),
                chunksSortMode: 'manual',
                chunks: entryPoints
            }),
            new CommonsChunkPlugin({
                name: ['entry'],
                chunks: ['bootstrap']
            }),
            new CommonsChunkPlugin({
                name: 'angular',
                chunks: ['bootstrap'],
                minChunks: module => /@angular/.test(module.resource)
            }),
            new CommonsChunkPlugin({
                name: ['thirdParty'],
                chunks: ['bootstrap'],
                minChunks: (module) => {
                    return module.resource &&
                        (module.resource.startsWith(nodeModules) ||
                            module.resource.startsWith(genDirNodeModules) ||
                            module.resource.startsWith(realNodeModules)
                        );
                }
            }),
            new WebpackOutputContentHashPlugin({
                manifestFiles: ['entry'],
                chunkHashLength: 12
            }),
            new ngtools.AotPlugin({
                skipCodeGeneration: false,
                typeChecking: false,
                tsConfigPath: config.tsConfigFile
            })
        ]
    }
};