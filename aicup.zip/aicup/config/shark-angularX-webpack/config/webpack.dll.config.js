const path = require('path');

const CheckDllExist = require('../utils/check-dll-exist');

const GenerateJsonPlugin = require('generate-json-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const ProgressBarWebpackPlugin = require('progress-bar-webpack-plugin');

const { SourceMapDevToolPlugin, ContextReplacementPlugin, DllPlugin } = require('webpack');

const getVersion = new CheckDllExist().getVersion;

module.exports = function(config) {
    return {
        entry: {
            angular: config.modules
        },
        output: {
            path: config.dllPath,
            filename: '[name].dll.js',
            library: '[name]_library'
        },
        module: {
            rules: [{
                    test: /\.ts$/,
                    use: [{
                            loader: 'awesome-typescript-loader',
                            options: {
                                silent: true,
                                useCache: true,
                                cacheDirectory: path.join(config.__dirname, 'node_modules/.cache/dll/'),
                                configFileName: config.tsConfigFile
                            }
                        },
                        'angular2-template-loader'
                    ]
                }, {
                    test: /\.html$/,
                    use: {
                        loader: 'html-loader'
                    }
                },
                {
                    test: /\.(jpg|png|webp|gif)$/,
                    use: {
                        loader: 'url-loader',
                        options: {
                            name: 'img/[name].[hash:12].[ext]' // 全部处理为 base64编码
                        }
                    }
                },
                {
                    test: /\.(otf|ttf|woff|woff2|ani|eot|svg|cur)$/,
                    loader: 'url-loader?name=font/[name].[hash:12].[ext]'
                },
                {
                    test: /\.scss$/,
                    use: ["to-string-loader", "css-loader", "sass-loader"]
                }
            ]
        },
        resolve: {
            extensions: ['.ts', '.js']
        },
        plugins: [
            new ProgressBarWebpackPlugin(),
            new CleanWebpackPlugin([config.dllPath + '/**/*'], {
                root: config.__dirname,
                verbose: false
            }),
            new ContextReplacementPlugin(
                /angular(\\|\/)core/
            ),
            new GenerateJsonPlugin('version.json', getVersion(config)),
            new DllPlugin({
                path: path.join(config.dllPath, '[name]-manifest.json'),
                name: '[name]_library'
            }),
            new SourceMapDevToolPlugin({
                filename: "[file].map[query]",
                moduleFilenameTemplate: "[resource-path]",
                fallbackModuleFilenameTemplate: "[resource-path]?[hash]",
                sourceRoot: "webpack:///"
            })
        ]
    }
};