const fs = require('fs');
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const OpenUrl = require('openurl');
const url = require('url');
const compression = require('compression');
const argv = require('yargs').argv;
const proxy = require('http-proxy-middleware'); //http请求转发
const IP = require('ip');
const PortFinder = require('portfinder');
const Chalk = require('chalk');
//webpack 配置
const SharkWebpack = require('../index');
const sharkWebpack = new SharkWebpack(require('../shark-deploy-conf'));
const SharkConfig = sharkWebpack.config;
const webpack = sharkWebpack.webpack;
const webpackDevMiddleware = sharkWebpack.webpackDevMiddleware;
const webpackHotMiddleware = sharkWebpack.webpackHotMiddleware;
const HtmlWebpackPlugin = require('html-webpack-plugin');
let port = argv.port || SharkConfig.port;
let clientUrl;
let indexHtml = 'index.html';
let app = express();
let server = () => {
    let devMiddleware;
    if (argv.env === 'dev') {
        // 使用默认配置时直接调用即可
        // 需要自定义添加 webpack 配置，请参考 shark-angularX-webpack 说明
        let webpackDevConfig = sharkWebpack.getDevConfig({
            plugins: 'replace-spec',
            entry: 'prepend'
        }, {
            plugins: [
                new HtmlWebpackPlugin({
                    filename: 'index2.html',
                    cache: false,
                    template: path.join(SharkConfig.srcPath, 'index.ejs'),
                    favicon: path.join(SharkConfig.srcPath, 'favicon.ico'),
                    excludeChunks: ['download']
                }),
                new HtmlWebpackPlugin({
                    filename: 'download.html',
                    cache: false,
                    template: path.join(SharkConfig.srcPath, 'download/download.html'),
                    chunksSortMode: 'manual',
                    chunks: ['polyfill', 'download']
                })
            ],
            entry: {
                'download': path.join(SharkConfig.srcPath, 'download/download.js')
            }
        });
        indexHtml = sharkWebpack.getIndexHtml(webpackDevConfig);
        let compiler = webpack(webpackDevConfig);
        devMiddleware = webpackDevMiddleware(compiler, {
            publicPath: webpackDevConfig.output.publicPath,
            noInfo: false,
            stats: {
                colors: true,
                modules: false,
                children: false,
                chunks: false,
                chunkModules: false,
                cachedAssets: false
            }
        });
        app.use(devMiddleware);
        app.use(webpackHotMiddleware(compiler, {
            reload: true
        }));
        // 使用build目录
    } else if (argv.env === 'build') {
        app.use(compression());
        app.use(SharkConfig.contextPath, express.static(SharkConfig.buildStatics));
        app.use(SharkConfig.contextPath, express.static(SharkConfig.buildWebapp));
    }

    // dev模式
    if (argv.server === 'mock') {
        app.use(bodyParser.urlencoded({extended: false}));
        app.use(bodyParser.json());
        //ajax mock
        app.use(SharkConfig.contextPath + '/xhr', function (req, res) {
            console.log(Chalk.green('[MOCK] Request url: ' + req.url));
            let data = path.join(SharkConfig.__dirname, 'test/mock/xhr', req.path);
            if (fs.existsSync(data)) {
                res.send(fs.readFileSync(data));
            } else {
                res.status(404).send('file not exist !');
            }
        });
    } else if (argv.server === 'remote') {
        // 联调模式
        let options = {
            target: SharkConfig.remote.url,
            changeOrigin: true
        };
        let httpProxy = proxy(options);
        //ajax server
        app.use(SharkConfig.contextPath + '/xhr', function (req, res) {
            console.log(Chalk.green('[REMOTE] Request url: ' + options.target + req.url));
            httpProxy(req, res);
        });
    }

    //font
    app.use(SharkConfig.contextPath + '/fonts', express.static(SharkConfig.assetsPath));

    //start server & listen
    PortFinder.getPortPromise({port: port})
        .then(unConflictPort => {
            let ip = IP.address();
            clientUrl = url.format(url.parse(`http://${ip}:${unConflictPort}${SharkConfig.contextPath}/${indexHtml}`));
            if (devMiddleware) {
                devMiddleware.waitUntilValid(() => {
                    console.log(Chalk.green('\nLive Development Server is listening on '), Chalk.blue.underline(clientUrl));
                    OpenUrl.open(clientUrl);
                })
            } else {
                console.log(Chalk.green('\nStatic Build Server is starting on '), Chalk.blue.underline(clientUrl));
                OpenUrl.open(clientUrl);
            }
            app.listen(unConflictPort)
        })
        .catch(err => {
            console.log(err)
        });
};
// 将原有 server 封装为方法，添加以下代码完成 dll 自动监测版本并自动完成编译
if (argv.env === 'dev') {
    sharkWebpack.checkDll().then((msg) => {
        console.log(msg);
        server();
    }, err => console.log(err));
} else {
    server();
}
