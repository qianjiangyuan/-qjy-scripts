const path = require('path');
const SharkWebpack = require('../index.js');
const sharkWebpack = new SharkWebpack(require('../shark-deploy-conf'));
const argv = require('yargs').argv;
// const HtmlWebpackPlugin = require('html-webpack-plugin');

// 在此处可以配置 build 过程中需要外接的 config文件
// const buildConfig = sharkWebpack.getBuildConfig({
//     plugins: 'replace-spec',
//     profile:'replace'
// }, {
//     plugins: [
//         new HtmlWebpackPlugin({
//             filename: 'index2.html',
//             template: path.join(sharkWebpack.config.srcPath, 'index.ejs')
//         })
//     ],
//     profile: false
// });

sharkWebpack.runBuild({
    target: argv.target, // required
    branch: argv.branch, // required
    // buildConfig: buildConfig, // optional
    callback: () => { // optional
        console.log('run after webpack finish')
    }
});
