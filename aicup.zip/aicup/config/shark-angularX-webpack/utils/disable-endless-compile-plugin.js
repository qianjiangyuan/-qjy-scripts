/**
 * @Author:  fuchao.zheng
 * @Desc:    用于解决首次编译时webpack多次编译问题，根据 webpack issue#2983
 */
class DisableEndlessCompilePlugin {
    apply(compiler) {
        const timeout = 10000;
        compiler.plugin('watch-run', (watching, cb) => {
            watching.startTime += timeout;
            cb()
        });
        compiler.plugin('done', (states) => {
            states.startTime -= timeout;
        })
    }
}

module.exports = DisableEndlessCompilePlugin;