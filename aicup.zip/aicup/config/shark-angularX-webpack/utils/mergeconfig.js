const path = require('path');
const fs = require('fs-extra');
const chalk = require('chalk');

let customModules = [
    '@angular/animations',
    '@angular/common',
    '@angular/core',
    '@angular/forms',
    '@angular/http',
    '@angular/platform-browser',
    '@angular/platform-browser-dynamic',
    '@angular/router'
];
let defaultPolyfillChunk = ['core-js/es7/reflect', 'zone.js/dist/zone'];
// 兼容 IE9及以上
let shimIE9 = [
    'core-js/es6',
    'core-js/es7',
    'classlist.js',
    'raf/polyfill.js',
    'intl',
    'intl/locale-data/jsonp/en.js'
];
let styleChunk = [process.cwd() + '/src/main/webapp/styles/scss/index.scss'];
let defaultConfig = {
    srcPath: '{{rootPath}}/src/main/webapp',
    assetsPath: '{{rootPath}}/src/main/webapp/assets/fonts',
    dllPath: '{{rootPath}}/dll',
    build: '{{rootPath}}/build',
    buildClient: '{{rootPath}}/build/client',
    buildWebapp: '{{rootPath}}/build/app',
    buildStatics: '{{rootPath}}/build/mimg',
    nodeModules: '{{rootPath}}/node_modules'
};

function getDefaultConfig(config) {
    let newConfig = {};
    for (let key in defaultConfig) {
        if (defaultConfig[key] instanceof Array) {
            defaultConfig[key].forEach((item, index, list) => {
                if (typeof item === 'string') {
                    item = item.replace('{{rootPath}}', config.__dirname);
                    list[index] = item;
                }
            });
            newConfig[key] = defaultConfig[key];
        } else if (typeof defaultConfig[key] === 'string') {
            newConfig[key] = defaultConfig[key].replace('{{rootPath}}', config.__dirname);
        } else {
            newConfig[key] = defaultConfig[key];
        }
    }
    return newConfig;
}

/**
 * 合并 polyfillChunk 与 shark-deploy.conf.js 中的 polyfillChunk 配置项
 *
 * @param {any} config 用户提供的 shark-deploy-conf 配置
 * @returns {Array} 添加了默认 polyfill 的 shark-deploy-conf 配置
 */
function mergePolyfill(config) {
    let result = [];
    if (config.shimIE9) {
        result = shimIE9.concat(defaultPolyfillChunk);
        console.log(chalk.yellow(`[INFO] openning IE9+ support`));
    }
    if (Array.isArray(config.polyfillChunk) && config.polyfillChunk.length > 0) {
        result = result.concat(config.polyfillChunk.concat(defaultPolyfillChunk));
        console.log(chalk.gray(`[INFO] polyfillChunk has config`));
    } else {
        result = result.concat(defaultPolyfillChunk);
    }
    return result.filter((item, pos) => result.lastIndexOf(item) === pos);
}

/**
 * 合并 styleChunk 与 shark-deploy.conf.js 中的 styleChunk 配置项
 *
 * @param {any} config 用户提供的 shark-deploy-conf 配置
 * @returns {Array} 添加了默认 全局 style （/src/main/webapp/styles/scss/index.scss）
 *                  的 shark-deploy-conf 配置
 */
function mergeStyleChunk(config) {
    let result = [];
    if (Array.isArray(config.styleChunk) && config.styleChunk.length > 0) {
        result = config.styleChunk;
        console.log(chalk.gray(`[INFO] StyleChunk has config`));
    } else {
        result = styleChunk;
    }
    return result.filter((item, pos) => result.indexOf(item) === pos);
}

/**
 * 合并 customModule 与 shark-deploy.conf.js 中的 customModule 配置项
 *
 * @param {any} config 用户提供的 shark-deploy-conf 配置
 * @returns config 添加了默认 modules(@angular) 的 shark-deploy-conf 配置
 */
function mergeModules(config) {
    let result = [];

    // const appPackage = require(path.join(config.__dirname, 'package.json'));
    // const dependencies = appPackage.dependencies || {};
    // customModules = Object.keys(dependencies).filter(dep => customModules.includes(dep));

    const angularPath = path.join(config.__dirname, 'node_modules', '@angular');
    const angularPackages = fs.readdirSync(angularPath) || [];
    customModules = customModules.filter(dep => {
        dep = dep.split('/')[1];
        return angularPackages.includes(dep)
    });

    if (Array.isArray(config.customModules) && config.customModules.length > 0) {
        result = customModules.concat(config.customModules);
        if (process.argv[1] && process.argv[1].split('/').pop() !== 'build') {
            // console.log(chalk.gray(`[INFO] CustomModules has config`));
        }
    } else {
        result = customModules;
    }
    return result.filter((item, pos) => result.indexOf(item) === pos);
}

module.exports = function (config) {
    let defaultConf = getDefaultConfig(config);
    let fileName = config.appTsConfigFileName || 'tsconfig.app.json';
    let appTsConfigFile = path.join(defaultConf.srcPath, fileName);
    let projectTsConfigFile = path.join(config.__dirname, 'tsconfig.json');

    if (fs.existsSync(appTsConfigFile)) {
        config.tsConfigFile = appTsConfigFile;
        console.log(chalk.gray(`[INFO] Using app tsconfig: ${fileName}`));
    } else {
        config.tsConfigFile = projectTsConfigFile;
    }
    if (!config.scssPath) config.scssPath = [];
    config.scssPath = config.scssPath.concat([])
        .map(i => path.join(defaultConf.nodeModules, i));
    return Object.assign(defaultConf, config, {
        modules: mergeModules(config),
        polyfillChunk: mergePolyfill(config),
        styleChunk: mergeStyleChunk(config)
    });
};