const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');
const { isEqual } = require('lodash');

class CheckDllExist {
    check(config) {
        let dll = path.join(config.__dirname, 'dll', 'angular.dll.js');
        let version = path.join(config.__dirname, 'dll', 'version.json');
        let hasDll = fs.existsSync(dll);
        let hasVersion = fs.existsSync(version);
        if (hasDll && hasVersion) {
            let nowVersion = this.getVersion(config);
            let oldVersion = require(version);
            if (!isEqual(oldVersion, nowVersion)) {
                return false
            }
        } else {
            return false
        }
        return true
    }

    getVersion(config) {
        let version = {};
        let nodePath = path.join(config.__dirname, 'node_modules');
        for (let module of config.modules) {
            let packagePath = path.join(nodePath, module, './package.json');
            let isInstalled = fs.existsSync(packagePath);
            if (!isInstalled) {
                console.log(chalk.red('[ERR] shark-deploy-config.customModules:', module, 'is not installed, install it first'));
                process.exit(0);
            } else {
                let pjson = require(packagePath);
                version[module] = pjson.version;
            }
        }
        return version;
    }
}

module.exports = CheckDllExist;